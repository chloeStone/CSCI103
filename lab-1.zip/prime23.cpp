#include <iostream>

using namespace std;

int main()
{
  int x;
  int twos = 0;
  int threes = 0;
  
  cout << "Enter a positive integer: " << endl;
  cin >> x;
  
  while(x % 2 == 0) //Checks for # of 2 factors
  {
    twos++;
    x /= 2;
  }
  
  while(x % 3 == 0) //Checks for # of 3 factors
  {
    threes++;
    x /= 3;
  }
  
  if ( x == 1)
  {
   cout << "Yes\n";
   cout << "Twos=" << twos << " Threes=" << threes << endl;
  }
  else
  {
    cout << "No\n";
  }

  return 0;
}