#include <iostream>

using namespace std;

int main()
{
  int num;
  
  cout << "Enter an integer between 0 and 999: ";
  cin >> num;
 
  cout << "1's digit is " << num % 10 << endl;
  cout << "10's digit is " << num/10 % 10 << endl;
  cout << "100's digit is: " << num/100 % 10 << endl;
}