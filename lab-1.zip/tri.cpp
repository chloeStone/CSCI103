#include <iostream>
#include <cmath>

using namespace std;

int main()
{
  double degrees;
  double radians;
  
  cout << "Enter the angle theta in degrees:\n";
  cin >> degrees; 
  
  radians = degrees * M_PI / 180;
  
  for (int i = 0; i < 31; i++) 
  {
    if(i== 0)
    {
      cout << " " << endl;
    }
    if(floor((i+1) * tan(radians)) >= 20 && floor((i+1) * tan(radians)) <= 30)
    {
      cout << "********************";
    }
    else
    {
      for (int j = 0; j < floor((i+1) * tan(radians)); j++) 
      {
         cout << "*";
      }    
    }
    cout << "\n";
  }
  
}