/* Author: Chloe Stonecipher
 * Program: color_conv
 * Description: Converts RGB -> CMYK color representation
 */
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
   int red;
   int green;
   int blue;
   double white;
   double cyan;
   double magenta;
   double yellow;
   double black;
  
   cout << "Enter 3 integers (red, green, and blue), in that order:";
   // Enter your code here
  
   cin >> red >> green >> blue;
  
   white = max(max(red, green), blue)/255.0;
   cyan = (white - red/255.0)/white;
   magenta = (white - green/255.0)/white; 
   yellow = (white - blue/255.0)/white;
   black = 1 - white;

   cout << "cyan: " << cyan << endl;
   cout << "magenta: " << magenta << endl;
   cout << "yellow: " << yellow << endl;
   cout << "black: " << black << endl;
  
   return 0;
}